# GUI Modern Parte 1/ FormularioModerno y Plano C# y WinForm
<img src="https://rjcodeadvance.com/wp-content/uploads/2019/06/Captura-de-pantalla-67.png">
<h1>Tutorial</h1>
<h2>YouTube</h2>
https://www.youtube.com/watch?v=eCSbUCL4teE
<h2>Blog</h2>
https://rjcodeadvance.com/disenar-interfaz-grafico-de-usuario-moderno-con-c-y-windows-form
